package app.osthir.camera;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Hosts the bundled web app (assets/www) in a WebView. Files are served from a
 * private https origin so getUserMedia works, and the camera feed stays inside
 * this app: the system camera app is never opened.
 */
public class MainActivity extends Activity {
    private static final String HOST = "appassets.local";
    private static final String ORIGIN = "https://" + HOST;
    private static final int REQ_CAMERA = 7;

    private WebView web;
    private PermissionRequest pendingRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        w.setStatusBarColor(Color.parseColor("#070806"));
        w.setNavigationBarColor(Color.parseColor("#070806"));

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#070806"));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.setWebViewClient(new AssetClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> handlePermission(request));
            }
        });

        web.loadUrl(ORIGIN + "/");
    }

    private void handlePermission(PermissionRequest request) {
        boolean wantsVideo = false;
        for (String r : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) wantsVideo = true;
        }
        if (!wantsVideo || !ORIGIN.equals(originOf(request.getOrigin()))) {
            request.deny();
            return;
        }
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
        } else {
            if (pendingRequest != null) pendingRequest.deny();
            pendingRequest = request;
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
        }
    }

    private static String originOf(Uri u) {
        return u.getScheme() + "://" + u.getHost();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code != REQ_CAMERA || pendingRequest == null) return;
        PermissionRequest r = pendingRequest;
        pendingRequest = null;
        if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
            r.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
        } else {
            r.deny();
            Toast.makeText(this, "ক্যামেরার অনুমতি লাগবে।", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onPause() {
        web.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        web.destroy();
        super.onDestroy();
    }

    /** Serves assets/www under the private https origin; blocks all other network access. */
    private class AssetClient extends WebViewClient {
        private final Map<String, String> mime = new HashMap<>();

        AssetClient() {
            mime.put("html", "text/html");
            mime.put("js", "text/javascript");
            mime.put("mjs", "text/javascript");
            mime.put("css", "text/css");
            mime.put("svg", "image/svg+xml");
            mime.put("png", "image/png");
            mime.put("jpg", "image/jpeg");
            mime.put("woff", "font/woff");
            mime.put("woff2", "font/woff2");
            mime.put("json", "application/json");
            mime.put("webmanifest", "application/manifest+json");
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
            Uri u = req.getUrl();
            if (!HOST.equals(u.getHost())) return blocked();
            String path = u.getPath();
            if (path == null || path.isEmpty() || path.equals("/")) path = "/index.html";
            if (path.contains("..")) return blocked();
            String ext = path.substring(path.lastIndexOf('.') + 1).toLowerCase(Locale.ROOT);
            // Client-side routes have no dot: always answer with the app shell.
            if (path.lastIndexOf('.') < path.lastIndexOf('/')) {
                path = "/index.html";
                ext = "html";
            }
            try {
                InputStream in = getAssets().open("www" + path);
                String type = mime.containsKey(ext) ? mime.get(ext) : "application/octet-stream";
                WebResourceResponse r = new WebResourceResponse(type, "utf-8", in);
                r.setStatusCodeAndReasonPhrase(200, "OK");
                return r;
            } catch (IOException e) {
                WebResourceResponse r = new WebResourceResponse("text/plain", "utf-8",
                        new ByteArrayInputStream(new byte[0]));
                r.setStatusCodeAndReasonPhrase(404, "Not Found");
                return r;
            }
        }

        private WebResourceResponse blocked() {
            WebResourceResponse r = new WebResourceResponse("text/plain", "utf-8",
                    new ByteArrayInputStream(new byte[0]));
            r.setStatusCodeAndReasonPhrase(403, "Blocked");
            return r;
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
            return !HOST.equals(req.getUrl().getHost());
        }
    }

    /** Saves a photo from the page into Pictures/Osthir. */
    private class Bridge {
        @JavascriptInterface
        public void saveImage(String base64, String name, String type) {
            try {
                byte[] data = Base64.decode(base64, Base64.DEFAULT);
                String safe = name == null ? "osthir.jpg" : name.replaceAll("[^A-Za-z0-9._-]", "_");
                if (type == null || !type.startsWith("image/")) type = "image/jpeg";
                ContentValues v = new ContentValues();
                v.put(MediaStore.Images.Media.DISPLAY_NAME, safe);
                v.put(MediaStore.Images.Media.MIME_TYPE, type);
                v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Osthir");
                v.put(MediaStore.Images.Media.IS_PENDING, 1);
                ContentResolver cr = getContentResolver();
                Uri uri = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
                if (uri == null) throw new IOException("insert failed");
                try (OutputStream out = cr.openOutputStream(uri)) {
                    out.write(data);
                }
                v.clear();
                v.put(MediaStore.Images.Media.IS_PENDING, 0);
                cr.update(uri, v, null, null);
                toast("গ্যালারিতে সেভ হয়েছে।");
            } catch (Exception e) {
                toast("সেভ করা যায়নি।");
            }
        }

        private void toast(final String msg) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
        }
    }
}
